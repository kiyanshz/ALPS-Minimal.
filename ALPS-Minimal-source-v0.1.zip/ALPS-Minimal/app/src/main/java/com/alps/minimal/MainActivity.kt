package com.alps.minimal

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 9, 11)
    private val panel = Color.rgb(19, 20, 23)
    private val line = Color.rgb(48, 49, 53)
    private val white = Color.rgb(245, 245, 242)
    private val muted = Color.rgb(151, 153, 158)
    private lateinit var root: LinearLayout
    private val handler = android.os.Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(22), dp(12), dp(22), dp(10))
    }
    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(18), dp(14), dp(18), dp(14))
    }
    private fun showHome() {
        root = base()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = text("ALPS  /  MINIMAL", 12f, muted, true)
        top.addView(brand, LinearLayout.LayoutParams(0, dp(28), 1f))
        val clock = text("--:--", 18f, white, true).apply { gravity = Gravity.END }
        top.addView(clock, LinearLayout.LayoutParams(dp(100), dp(28)))
        root.addView(top)
        handler.post(object : Runnable { override fun run() { clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); handler.postDelayed(this, 1000) } })
        val date = text(SimpleDateFormat("EEEE  •  d MMMM", Locale.getDefault()).format(Date()), 12f, muted)
        root.addView(date, LinearLayout.LayoutParams(-1, dp(24)))
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, dp(12)) }
        val map = card()
        map.addView(text("NAVIGATION", 11f, muted, true))
        map.addView(text("Ready when you are", 21f, white, true), LinearLayout.LayoutParams(-1, 0, 1f))
        map.addView(text("Open maps for directions", 12f, muted))
        map.setOnClickListener { launchMaps() }
        body.addView(map, LinearLayout.LayoutParams(0, 0, 1.25f).apply { height = -1; rightMargin = dp(8) })
        val music = card()
        music.addView(text("NOW PLAYING", 11f, muted, true))
        music.addView(text("Music", 23f, white, true), LinearLayout.LayoutParams(-1, 0, 1f))
        music.addView(text("Open your music player", 12f, muted))
        music.setOnClickListener { openMusic() }
        body.addView(music, LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(8) })
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        val dock = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        dock.addView(action("HOME") { showHome() }, weight())
        dock.addView(action("APPS") { showApps() }, weight())
        dock.addView(action("MAP") { launchMaps() }, weight())
        dock.addView(action("MUSIC") { openMusic() }, weight())
        dock.addView(action("SETTINGS") { openSettings() }, weight())
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(48)))
        setContentView(root)
    }
    private fun weight() = LinearLayout.LayoutParams(0, -1, 1f)
    private fun action(label: String, click: () -> Unit) = TextView(this).apply {
        text = label; textSize = 10f; setTextColor(white); gravity = Gravity.CENTER
        setOnClickListener { click() }
    }
    private fun showApps() {
        val page = base()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("APPLICATIONS", 15f, white, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(action("BACK") { showHome() }, LinearLayout.LayoutParams(dp(70), dp(42)))
        page.addView(header)
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = true }
        val pm = packageManager
        val apps = pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        apps.forEach { info ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(10), dp(4), dp(10)) }
            val icon = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(info)); scaleType = ImageView.ScaleType.FIT_CENTER }
            item.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            item.addView(text(pm.getApplicationLabel(info).toString(), 10f, white).apply { gravity = Gravity.CENTER; maxLines = 2 }, LinearLayout.LayoutParams(-1, dp(34)))
            item.setOnClickListener { pm.getLaunchIntentForPackage(info.packageName)?.let { startActivity(it) } }
            grid.addView(item, GridLayout.LayoutParams().apply { width = 0; height = dp(88); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
        }
        scroll.addView(grid); page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(page)
    }
    private fun launchMaps() {
        val intent = packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
        if (intent != null) startActivity(intent) else Toast.makeText(this, "No compatible maps app found", Toast.LENGTH_SHORT).show()
    }
    private fun openMusic() {
        val candidates = listOf("com.google.android.music", "com.spotify.music", "com.android.music")
        val intent = candidates.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (intent != null) startActivity(intent) else showApps()
    }
    private fun openSettings() { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
    override fun onBackPressed() { showHome() }
}
